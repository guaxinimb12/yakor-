var searchData=
[
  ['ext_5fcache_5fdir',['EXT_CACHE_DIR',['../classgg.html#a739b7970aa660ac8577f5dc5ad01434d',1,'gg']]],
  ['ext_5ffiles_5fdir',['EXT_FILES_DIR',['../classgg.html#ab6dd8e565796ce5e6eabcf43065c3be9',1,'gg']]],
  ['ext_5fstorage',['EXT_STORAGE',['../classgg.html#a00694bfb6870e041b9c22021ba9713e2',1,'gg']]]
];
