var searchData=
[
  ['choice',['choice',['../classgg.html#a2226dc4fe42a97691506d63e9305c728',1,'gg']]],
  ['clearlist',['clearList',['../classgg.html#a6c58075296a69351c0716745c53586a7',1,'gg']]],
  ['clearresults',['clearResults',['../classgg.html#ae8f5b6b09c5772ca866b689675e619d8',1,'gg']]],
  ['copymemory',['copyMemory',['../classgg.html#aa6e3128804642403defc1f1004303171',1,'gg']]],
  ['copytext',['copyText',['../classgg.html#ad815b037629912b68ce6e028a05f04fd',1,'gg']]]
];
