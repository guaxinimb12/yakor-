var searchData=
[
  ['save_5fas_5ftext',['SAVE_AS_TEXT',['../classgg.html#a71b43848f273747d7d23b2b928997ec8',1,'gg']]],
  ['sign_5fequal',['SIGN_EQUAL',['../classgg.html#abbeb4e97410b798aafde34f6bd4e5b1b',1,'gg']]],
  ['sign_5ffuzzy_5fequal',['SIGN_FUZZY_EQUAL',['../classgg.html#a07729687f603d1c7e442f53dc23d5c03',1,'gg']]],
  ['sign_5ffuzzy_5fgreater',['SIGN_FUZZY_GREATER',['../classgg.html#aacb314da675d9fbb44131c09afa2019b',1,'gg']]],
  ['sign_5ffuzzy_5fless',['SIGN_FUZZY_LESS',['../classgg.html#ad57b335ad30ec345ebe2b1d67d5ed812',1,'gg']]],
  ['sign_5ffuzzy_5fnot_5fequal',['SIGN_FUZZY_NOT_EQUAL',['../classgg.html#aa83914cbe300f0c82a30a17d38e67af4',1,'gg']]],
  ['sign_5fgreater_5for_5fequal',['SIGN_GREATER_OR_EQUAL',['../classgg.html#a5ee77c62ddcaf20d23b6e654b9e670fb',1,'gg']]],
  ['sign_5fless_5for_5fequal',['SIGN_LESS_OR_EQUAL',['../classgg.html#a8751aeae8920a5c87535d00f05d21f11',1,'gg']]],
  ['sign_5fnot_5fequal',['SIGN_NOT_EQUAL',['../classgg.html#a0c18d03d45168220e55194396e89dd2b',1,'gg']]]
];
