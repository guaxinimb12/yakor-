var searchData=
[
  ['ispackageinstalled',['isPackageInstalled',['../classgg.html#adee31e961b7c3a6c6b2f9b50f84ef5d5',1,'gg']]],
  ['isprocesspaused',['isProcessPaused',['../classgg.html#abf769c87d2eca8b2a61847c9e9b5440e',1,'gg']]],
  ['isvisible',['isVisible',['../classgg.html#aadc2f7e6c414e3e7016fb654293daa7f',1,'gg']]]
];
