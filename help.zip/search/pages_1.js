var searchData=
[
  ['frequently_20asked_20questions',['Frequently asked questions',['../faq.html',1,'']]]
];
