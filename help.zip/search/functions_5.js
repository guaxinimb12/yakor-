var searchData=
[
  ['getfile',['getFile',['../classgg.html#a835c5691f8e6512057a87e86169a0164',1,'gg']]],
  ['getline',['getLine',['../classgg.html#a9f4b62778af4c46ebfadedd8f910025f',1,'gg']]],
  ['getlistitems',['getListItems',['../classgg.html#a4fd09c150fe2527816abb729dfea2801',1,'gg']]],
  ['getlocale',['getLocale',['../classgg.html#a4104ba09f92838c41afdcb011ed6b134',1,'gg']]],
  ['getranges',['getRanges',['../classgg.html#a046c4d7d9ad8e9a05f31f0b22f815da6',1,'gg']]],
  ['getrangeslist',['getRangesList',['../classgg.html#a8bb9745b0b7ae43f8a228a373031b1ed',1,'gg']]],
  ['getresults',['getResults',['../classgg.html#ad0bd7945d37dd140f977ba7180d220f6',1,'gg']]],
  ['getresultscount',['getResultsCount',['../classgg.html#a1123e55c5eb365b425ccfe465c52c510',1,'gg']]],
  ['getspeed',['getSpeed',['../classgg.html#a2e4acdf2555e25e9230213f7b8c9a0d2',1,'gg']]],
  ['gettargetinfo',['getTargetInfo',['../classgg.html#a312c7d90473026e38c67ffd24fd970d7',1,'gg']]],
  ['gettargetpackage',['getTargetPackage',['../classgg.html#a7593ecb25a430e1f2dfda805a7799ce8',1,'gg']]],
  ['getvalues',['getValues',['../classgg.html#aae2b60904e15c3612a0d2d6385e0e3e3',1,'gg']]],
  ['getvaluesrange',['getValuesRange',['../classgg.html#a1d5e6284862c444be70ab4cc0c805cc0',1,'gg']]],
  ['gotoaddress',['gotoAddress',['../classgg.html#a44294c4496b6b87ba9589d2691e70728',1,'gg']]]
];
