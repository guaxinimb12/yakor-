var searchData=
[
  ['savelist',['saveList',['../classgg.html#a18bdecc384ccee353a2fc2eab24b0c5b',1,'gg']]],
  ['savevariable',['saveVariable',['../classgg.html#a204f5dea60cac80c39521ceb4936a83b',1,'gg']]],
  ['searchaddress',['searchAddress',['../classgg.html#ad618c6f3077f4ec3719f6f2d9e68a56f',1,'gg']]],
  ['searchfuzzy',['searchFuzzy',['../classgg.html#a671d80f412a7f7667fcb3215e2773e94',1,'gg']]],
  ['searchnumber',['searchNumber',['../classgg.html#a7efd4ac7766e72688cb4a84a3915721e',1,'gg']]],
  ['setranges',['setRanges',['../classgg.html#a26f376a1d243ec199b1ae48578d2a303',1,'gg']]],
  ['setspeed',['setSpeed',['../classgg.html#a9251c9728e8ce91588581222a885457e',1,'gg']]],
  ['setvalues',['setValues',['../classgg.html#a91d0ba1d5ff843ce26eef210dae956f1',1,'gg']]],
  ['setvisible',['setVisible',['../classgg.html#a6d8ab51c745808c554f4f953d8e05c94',1,'gg']]],
  ['skiprestorestate',['skipRestoreState',['../classgg.html#adeeda53b8c73719751b8a61682686152',1,'gg']]],
  ['sleep',['sleep',['../classgg.html#a5f281d50d0ff0846c9c0594a61895dce',1,'gg']]],
  ['startfuzzy',['startFuzzy',['../classgg.html#ac354c6369c05ffeeca79a1b61f4a6550',1,'gg']]]
];
